<?php
$username="id17436211_root";
$password="Makayath@0101";
$dbname="id17436211_foodmania";
$hostname="localhost";
$con=mysqli_connect($hostname,$username,$password,$dbname);




?>